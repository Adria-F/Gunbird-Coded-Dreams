# GunBird by Coded Dreams

We're going to copy some of the levels about the game called Gunbird. 
From the sounds to the enemies.


## Installation

Decompress the .zip file and execute the executable inside the decompressed folder.


##Usage (version 0.4)

Character
WASD: move character
F key: shoot

Debugging Mode
Tab: activate / deactivate
Arrow keys: move camera

Colliders
F1: activate / deactivate


##Usage (original game)

Control-> Shoot

Shift-> Special Attack

Arrow Keys-> Move the character

5--> Insert Coin

1--> Join Player l

2--> Join Player 2


## Contributing

Write below all the contributions you do to the game and put a time stamp.

Example:

-Josep Pi[24/02/2017 9:05] Writing the readme in the repository.

-Adri� Ferrer[25/02/2017 21:09] Updating the readme in the repository.


#History

The story tells a tale of how the protagonists are trying to collect pieces of a magic mirror to make a wish.


## Credits

Adri� Ferrer

Vladimir Agache

Pau Llopart

Norman Benet

Josep Pi


## License

Psikyo